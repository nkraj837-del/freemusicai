# FreeMusicAI — Free Browser Music Demo

A mobile-friendly Hindi/English static website. It creates a simple synthesized instrumental demo in your browser and lets you play or download it as WAV.

## Run on a phone or computer
1. Extract `FreeMusicAI_website.zip`.
2. Open `index.html` in Chrome or another modern browser.
3. Choose music style, mood, tempo, and duration.
4. Tap **इंस्ट्रुमेंटल डेमो बनाएं**, then Play or WAV डाउनलोड.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a **public** repository (for example `freemusicai`).
2. Upload `index.html` to the repository's top/root level.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
5. Wait for GitHub Pages to publish and use the URL shown in the Pages settings.

## Important limitation
This is a no-cost browser demo, not a full AI singing service. It synthesizes instrumental tones locally; it does not sing lyrics or generate full AI songs. Real AI vocals require an appropriate AI model/API and may have usage limits or costs. This ZIP does not publish the website automatically; you must upload it to a hosting service.
